﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void BulletScript::Start()
extern void BulletScript_Start_mE1540DCCC21C30A4A051D5303825C43056A6B31D ();
// 0x00000002 System.Void BulletScript::FixedUpdate()
extern void BulletScript_FixedUpdate_m049D65792F61A1D9A5872DF514A2013DAD79249D ();
// 0x00000003 System.Void BulletScript::OnCollisionEnter2D(UnityEngine.Collision2D)
extern void BulletScript_OnCollisionEnter2D_m0A6C455339529C439CDE9A8FB9AE904D54C19D80 ();
// 0x00000004 System.Void BulletScript::.ctor()
extern void BulletScript__ctor_m3C3443296F2DFB03D923B031E234DD5EC8E798FA ();
// 0x00000005 System.Void BulletSpawner::Start()
extern void BulletSpawner_Start_mD3541B3DD19D27FB4A71C02AF63EFB5512BD3606 ();
// 0x00000006 System.Collections.IEnumerator BulletSpawner::BulletManager()
extern void BulletSpawner_BulletManager_mF83D073F4C36111512FC91C783E294A59018E2EA ();
// 0x00000007 System.Void BulletSpawner::.ctor()
extern void BulletSpawner__ctor_mF6156A47F7C68A318F0D9B3A953AB5321AE72532 ();
// 0x00000008 System.Void DeadItCleanup::Start()
extern void DeadItCleanup_Start_m35417716EEB79C8147DA5B5715CEA5B9B16BD967 ();
// 0x00000009 System.Void DeadItCleanup::Update()
extern void DeadItCleanup_Update_m9D4CE551A73FBEEC40414157A0BB17897FE22E2F ();
// 0x0000000A System.Void DeadItCleanup::Dead()
extern void DeadItCleanup_Dead_mD7F89BF43A9C8C61D81406F45523CEAED9FAE434 ();
// 0x0000000B System.Void DeadItCleanup::.ctor()
extern void DeadItCleanup__ctor_m3C5C54F7C573708E8AB5C9DE319DE21FC7D2FCCE ();
// 0x0000000C System.Void SimplePlayerMovement::Start()
extern void SimplePlayerMovement_Start_m6135FDC5E568056155D57FF0175F4552F1473362 ();
// 0x0000000D System.Void SimplePlayerMovement::FixedUpdate()
extern void SimplePlayerMovement_FixedUpdate_m16C444C85CB5BAE76737979405A788E04A416DF2 ();
// 0x0000000E System.Void SimplePlayerMovement::OnCollisionEnter2D(UnityEngine.Collision2D)
extern void SimplePlayerMovement_OnCollisionEnter2D_m154BF2F685A6422B44BBDAA6AB6E65BB0E53EA1E ();
// 0x0000000F System.Void SimplePlayerMovement::.ctor()
extern void SimplePlayerMovement__ctor_m172E9B5F45F39F6FE7A92C896A51872668995DC4 ();
// 0x00000010 System.Void SimpleSphereMovement::Start()
extern void SimpleSphereMovement_Start_m8EBF2C0F6A31D245431D8A6738BD9ADDC94B606C ();
// 0x00000011 System.Void SimpleSphereMovement::FixedUpdate()
extern void SimpleSphereMovement_FixedUpdate_mA82D79E6E9D0381215FF46119A121B10122A31A1 ();
// 0x00000012 System.Void SimpleSphereMovement::OnCollisionEnter2D(UnityEngine.Collision2D)
extern void SimpleSphereMovement_OnCollisionEnter2D_mC4CA0FA2F27C9D30363E5C7BFC09C6AF0DFCE475 ();
// 0x00000013 System.Void SimpleSphereMovement::.ctor()
extern void SimpleSphereMovement__ctor_m6F307191F6643189A674575912DEEC75C58C993E ();
// 0x00000014 System.Void StartGameScript::Start()
extern void StartGameScript_Start_mF709FBEED8875553FD9E05265C16D082D7DA0CFD ();
// 0x00000015 System.Void StartGameScript::Update()
extern void StartGameScript_Update_mE28FDAFB38F7EE74B4BD1D6F3B2532E20A1CA3A4 ();
// 0x00000016 System.Void StartGameScript::.ctor()
extern void StartGameScript__ctor_mAD0B75E64A6CCA2B5E09EA4DA54A5EE1FCDC57F4 ();
// 0x00000017 System.Void TrapScript::Start()
extern void TrapScript_Start_m2F41C66FD7B54C9F6C5E4FACE4AA205048666C8D ();
// 0x00000018 System.Void TrapScript::FixedUpdate()
extern void TrapScript_FixedUpdate_mABE32F0FF13BED4EF2433DDA87036DE0A8225E2D ();
// 0x00000019 System.Void TrapScript::.ctor()
extern void TrapScript__ctor_mC44F0629C69CEBFDEC6CDA42F4AE5EEA88437258 ();
// 0x0000001A System.Void TrapWatchOutForPlayer::Start()
extern void TrapWatchOutForPlayer_Start_m87968A8055CA90EE530B94B9E12C44B9E1EDA9E4 ();
// 0x0000001B System.Void TrapWatchOutForPlayer::OnCollisionEnter2D(UnityEngine.Collision2D)
extern void TrapWatchOutForPlayer_OnCollisionEnter2D_m5CA91364C7063743173B861D0C0335D14A0FDD3D ();
// 0x0000001C System.Void TrapWatchOutForPlayer::.ctor()
extern void TrapWatchOutForPlayer__ctor_mCE05C635ACB76B8ECFC4BD5C3BFA66F818056C97 ();
// 0x0000001D System.Void BulletSpawner_<BulletManager>d__9::.ctor(System.Int32)
extern void U3CBulletManagerU3Ed__9__ctor_m21F2D7A00E78D307C4EB6AF7DED370F4CDFE2F5C ();
// 0x0000001E System.Void BulletSpawner_<BulletManager>d__9::System.IDisposable.Dispose()
extern void U3CBulletManagerU3Ed__9_System_IDisposable_Dispose_m2BC51C2481571E6DAB96670F39B506A6628CEF40 ();
// 0x0000001F System.Boolean BulletSpawner_<BulletManager>d__9::MoveNext()
extern void U3CBulletManagerU3Ed__9_MoveNext_m9576B9D390E4A5CE5C4F40DF35C93A1C8E304B8F ();
// 0x00000020 System.Object BulletSpawner_<BulletManager>d__9::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CBulletManagerU3Ed__9_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m178D1546E32A2FF605403ECAEB9430469EB4F358 ();
// 0x00000021 System.Void BulletSpawner_<BulletManager>d__9::System.Collections.IEnumerator.Reset()
extern void U3CBulletManagerU3Ed__9_System_Collections_IEnumerator_Reset_m10920924AD699EF35A6BF469A7B7E3C33F150B1C ();
// 0x00000022 System.Object BulletSpawner_<BulletManager>d__9::System.Collections.IEnumerator.get_Current()
extern void U3CBulletManagerU3Ed__9_System_Collections_IEnumerator_get_Current_m1B7FA194ECEEC1C50E7EF75A5E2987AC71A22D79 ();
static Il2CppMethodPointer s_methodPointers[34] = 
{
	BulletScript_Start_mE1540DCCC21C30A4A051D5303825C43056A6B31D,
	BulletScript_FixedUpdate_m049D65792F61A1D9A5872DF514A2013DAD79249D,
	BulletScript_OnCollisionEnter2D_m0A6C455339529C439CDE9A8FB9AE904D54C19D80,
	BulletScript__ctor_m3C3443296F2DFB03D923B031E234DD5EC8E798FA,
	BulletSpawner_Start_mD3541B3DD19D27FB4A71C02AF63EFB5512BD3606,
	BulletSpawner_BulletManager_mF83D073F4C36111512FC91C783E294A59018E2EA,
	BulletSpawner__ctor_mF6156A47F7C68A318F0D9B3A953AB5321AE72532,
	DeadItCleanup_Start_m35417716EEB79C8147DA5B5715CEA5B9B16BD967,
	DeadItCleanup_Update_m9D4CE551A73FBEEC40414157A0BB17897FE22E2F,
	DeadItCleanup_Dead_mD7F89BF43A9C8C61D81406F45523CEAED9FAE434,
	DeadItCleanup__ctor_m3C5C54F7C573708E8AB5C9DE319DE21FC7D2FCCE,
	SimplePlayerMovement_Start_m6135FDC5E568056155D57FF0175F4552F1473362,
	SimplePlayerMovement_FixedUpdate_m16C444C85CB5BAE76737979405A788E04A416DF2,
	SimplePlayerMovement_OnCollisionEnter2D_m154BF2F685A6422B44BBDAA6AB6E65BB0E53EA1E,
	SimplePlayerMovement__ctor_m172E9B5F45F39F6FE7A92C896A51872668995DC4,
	SimpleSphereMovement_Start_m8EBF2C0F6A31D245431D8A6738BD9ADDC94B606C,
	SimpleSphereMovement_FixedUpdate_mA82D79E6E9D0381215FF46119A121B10122A31A1,
	SimpleSphereMovement_OnCollisionEnter2D_mC4CA0FA2F27C9D30363E5C7BFC09C6AF0DFCE475,
	SimpleSphereMovement__ctor_m6F307191F6643189A674575912DEEC75C58C993E,
	StartGameScript_Start_mF709FBEED8875553FD9E05265C16D082D7DA0CFD,
	StartGameScript_Update_mE28FDAFB38F7EE74B4BD1D6F3B2532E20A1CA3A4,
	StartGameScript__ctor_mAD0B75E64A6CCA2B5E09EA4DA54A5EE1FCDC57F4,
	TrapScript_Start_m2F41C66FD7B54C9F6C5E4FACE4AA205048666C8D,
	TrapScript_FixedUpdate_mABE32F0FF13BED4EF2433DDA87036DE0A8225E2D,
	TrapScript__ctor_mC44F0629C69CEBFDEC6CDA42F4AE5EEA88437258,
	TrapWatchOutForPlayer_Start_m87968A8055CA90EE530B94B9E12C44B9E1EDA9E4,
	TrapWatchOutForPlayer_OnCollisionEnter2D_m5CA91364C7063743173B861D0C0335D14A0FDD3D,
	TrapWatchOutForPlayer__ctor_mCE05C635ACB76B8ECFC4BD5C3BFA66F818056C97,
	U3CBulletManagerU3Ed__9__ctor_m21F2D7A00E78D307C4EB6AF7DED370F4CDFE2F5C,
	U3CBulletManagerU3Ed__9_System_IDisposable_Dispose_m2BC51C2481571E6DAB96670F39B506A6628CEF40,
	U3CBulletManagerU3Ed__9_MoveNext_m9576B9D390E4A5CE5C4F40DF35C93A1C8E304B8F,
	U3CBulletManagerU3Ed__9_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m178D1546E32A2FF605403ECAEB9430469EB4F358,
	U3CBulletManagerU3Ed__9_System_Collections_IEnumerator_Reset_m10920924AD699EF35A6BF469A7B7E3C33F150B1C,
	U3CBulletManagerU3Ed__9_System_Collections_IEnumerator_get_Current_m1B7FA194ECEEC1C50E7EF75A5E2987AC71A22D79,
};
static const int32_t s_InvokerIndices[34] = 
{
	23,
	23,
	26,
	23,
	23,
	14,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	26,
	23,
	23,
	23,
	26,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	26,
	23,
	32,
	23,
	114,
	14,
	23,
	14,
};
extern const Il2CppCodeGenModule g_AssemblyU2DCSharpCodeGenModule;
const Il2CppCodeGenModule g_AssemblyU2DCSharpCodeGenModule = 
{
	"Assembly-CSharp.dll",
	34,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
