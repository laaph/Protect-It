#pragma once

#include <stdint.h>

#include "Generated/CultureInfoInternalsNet_4_0.h"
